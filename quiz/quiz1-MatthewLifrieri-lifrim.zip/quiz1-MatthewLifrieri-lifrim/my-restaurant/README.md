References(image sources)/Inspirations:
-https://cookingwithayeh.com/shrimp-tempura-roll/
-https://www.allrecipes.com/recipe/14759/pork-dumplings/
-https://spicysouthernkitchen.com/general-tsos-chicken/
-https://modernmealmakeover.com/teriyaki-chicken/
-https://sarkura-japan.res-menu.com/
-https://lins-family-chinese.edan.io/

For parts 1-3 of quiz 1, I designed a 4-item menu for a fictional restaurant. I first had to design the JSON file that would include that data for my menu items. I went with my go-to orders from my local Chinese and Japanese restaurants back home. Figuring out generic recipes and finding images after that was pretty simple, and I included my sources up above. My restaurant was following a trend of southeast/eastern Asian cuisine, so I came up with the name East Feast. I then created my HTML document, defining the elements my 4 menu items would be generated into by AJAX, as well as a header and footer for my menu. I then designed my CSS, taking inspiration from my previous labs, such as including animated movement when an item is hovered and sticky header and footer. Lastly, I designed the AJAX within my JavaScript file. This was really simple, only including the fetch request, a loop to display all my data, and error catching messages.